﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LiteNetLib;
using LiteNetLib.Utils;
using System.Net;
using System.Net.Sockets;
using System;
using System.Threading;

public class Client : MonoBehaviour, INetEventListener{
    public NetManager netClient;
    public NetPeer serverPeer;
    private readonly NetPacketProcessor _netPacketProcessor = new NetPacketProcessor();

    void Start(){
        Start_Client();
    }

    // Update is called once per frame
    void Update(){
        netClient.PollEvents();
        Thread.Sleep(15);

        if(Input.GetKeyUp(KeyCode.Space)) {
            if(serverPeer != null && serverPeer.ConnectionState == ConnectionState.Connected) {
                Send_Client_Message("JoMamma",""+DateTime.Now.ToString("M/d/y hh:mm:ss tt")+"Client: has sent message of random number: "+UnityEngine.Random.Range(0.0f,10000.0f));
            }
        }
    }

    public void Start_Client() {
        _netPacketProcessor.SubscribeReusable<NetMessage, NetPeer>(OnNetMessageReceived);
        netClient = new NetManager(this);
        netClient.Start();
        netClient.UpdateTime = 15;

        serverPeer = netClient.Connect("localhost",5000,"SomeKey");

        Debug.Log("Server has started on port 5000...");
    }


    public void Stop_Client() {
        netClient.Stop();

    }

    public void Send_Client_Message(string tName, string tMess) {
        NetMessage myMessage = new NetMessage();
        myMessage.ntName = tName;
        myMessage.ntMessage = tMess;
        _netPacketProcessor.Send(netClient,myMessage,DeliveryMethod.ReliableOrdered);

    }

    public void OnNetMessageReceived(NetMessage tNetMessage, NetPeer peer) {
        //This will happen when 
        Debug.Log("OnNetMessageReceived");

    }

    public void OnPeerConnected(NetPeer peer) {
        //throw new System.NotImplementedException();
        Debug.Log("Client: OnPeerConnected");
    }

    public void OnPeerDisconnected(NetPeer peer,DisconnectInfo disconnectInfo) {
        //throw new System.NotImplementedException();
        Debug.Log("Client: OnPeerDisConnected");
    }

    public void OnNetworkError(IPEndPoint endPoint,SocketError socketError) {
        //throw new System.NotImplementedException();
        Debug.Log("Client: OnNetworkError");
    }

    public void OnNetworkReceive(NetPeer peer,NetPacketReader reader,DeliveryMethod deliveryMethod) {
        //throw new System.NotImplementedException();
        Debug.Log("Client: OnNetworkReceive");
        _netPacketProcessor.ReadAllPackets(reader, peer);
        //_netPacketProcessor.ReadPacket(reader);
    }

    public void OnNetworkReceiveUnconnected(IPEndPoint remoteEndPoint,NetPacketReader reader,UnconnectedMessageType messageType) {
        //throw new System.NotImplementedException();
        Debug.Log("Client: OnNetworkReceiveUnconnected");
    }

    public void OnNetworkLatencyUpdate(NetPeer peer,int latency) {
        //throw new System.NotImplementedException();
        //Debug.Log("Client: OnnetworkLatencyUpdate");
    }

    public void OnConnectionRequest(ConnectionRequest request) {
        //throw new System.NotImplementedException();
        Debug.Log("Client: OnConnectionRequest");
    }

    public class NetMessage{
        public string ntName;
        public string ntMessage;
    }
}
