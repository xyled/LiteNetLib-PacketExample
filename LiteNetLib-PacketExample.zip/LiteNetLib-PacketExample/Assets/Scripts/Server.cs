﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LiteNetLib;
using LiteNetLib.Utils;
using System.Net;
using System.Net.Sockets;
using System;
using System.Threading;

public class Server : MonoBehaviour,INetEventListener{
    public NetManager netServer;
    public NetPeer clientPeer;
    private readonly NetPacketProcessor _netPacketProcessor = new NetPacketProcessor();


    // Start is called before the first frame update
    void Start(){
        Start_Server();
    }

    // Update is called once per frame
    void Update(){
        netServer.PollEvents();
        Thread.Sleep(15);

        if(Input.GetKeyUp(KeyCode.Return)) {
            if(clientPeer != null && clientPeer.ConnectionState == ConnectionState.Connected) {
                Send_Server_Message("JoMamma",""+DateTime.Now.ToString("M/d/y hh:mm:ss tt")+"Client: has sent message of random number: "+UnityEngine.Random.Range(0.0f,10000.0f));
            }
        }
    }

    public void Start_Server() {
        _netPacketProcessor.SubscribeReusable<NetMessage, NetPeer>(OnNetMessageReceived);
        netServer = new NetManager(this);
        netServer.Start(5000);
        netServer.UpdateTime = 15;

        Debug.Log("Server has started on port 5000...");
    }

    public void Stop_Server() {
        netServer.Stop();

    }

    public void Send_Server_Message(string tName, string tMess) {
        NetMessage myMessage = new NetMessage();
        myMessage.ntName = tName;
        myMessage.ntMessage = tMess;
        _netPacketProcessor.Send(netServer,myMessage,DeliveryMethod.ReliableOrdered);

    }

    public void OnNetMessageReceived(NetMessage tNetMessage, NetPeer peer) {
        Debug.Log("Server: OnNetMessageReceived");

    }

    public void OnPeerConnected(NetPeer peer) {
        //throw new System.NotImplementedException();
        Debug.Log("Server: OnPeerConnected");
        clientPeer = peer;
    }

    public void OnPeerDisconnected(NetPeer peer,DisconnectInfo disconnectInfo) {
        //throw new System.NotImplementedException();
        Debug.Log("Server: OnPeerDisConnected");
    }

    public void OnNetworkError(IPEndPoint endPoint,SocketError socketError) {
        //throw new System.NotImplementedException();
        Debug.Log("Server: OnNetworkError");
    }

    public void OnNetworkReceive(NetPeer peer,NetPacketReader reader,DeliveryMethod deliveryMethod) {
        //throw new System.NotImplementedException();
        Debug.Log("Server: OnNetworkReceive");
        _netPacketProcessor.ReadAllPackets(reader, peer);
        //_netPacketProcessor.ReadPacket(reader);
    }

    public void OnNetworkReceiveUnconnected(IPEndPoint remoteEndPoint,NetPacketReader reader,UnconnectedMessageType messageType) {
        //throw new System.NotImplementedException();
        Debug.Log("Server: OnNetworkReceiveUnconnected");
    }

    public void OnNetworkLatencyUpdate(NetPeer peer,int latency) {
        //throw new System.NotImplementedException();
        //Debug.Log("Server: OnnetworkLatencyUpdate");
    }

    public void OnConnectionRequest(ConnectionRequest request) {
        //throw new System.NotImplementedException();
        Debug.Log("Server: OnConnectionRequest");
        request.AcceptIfKey("SomeKey");
    }

    public class NetMessage{
        public string ntName;
        public string ntMessage;
    }
}
