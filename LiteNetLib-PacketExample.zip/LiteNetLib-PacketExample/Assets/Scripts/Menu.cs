﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Menu : MonoBehaviour{

    public GameObject goServer;
    public GameObject goClient;
    public Button butStartServer;
    public Button butStartClient;

    // Start is called before the first frame update
    void Start(){
        butStartServer = GameObject.Find("Button_StartServer").GetComponent<Button>();
        butStartClient = GameObject.Find("Button_StartClient").GetComponent<Button>();
    }

    // Update is called once per frame
    void Update(){

    }

    public void Start_Server() {
        goServer = Instantiate(Resources.Load("Prefabs/GO_Server")) as GameObject;
        butStartServer.interactable = false;

    }

    public void Start_Client() {
        goClient = Instantiate(Resources.Load("Prefabs/GO_Client")) as GameObject;
        butStartServer.interactable = false;
        butStartClient.interactable = false;

    }

    public void Stop_All() {
        if(goServer != null) {
            goServer.GetComponent<Server>().Stop_Server();
            Destroy(goServer);
            butStartServer.interactable = true;
        }

        if(goClient != null) {
            goClient.GetComponent<Client>().Stop_Client();
            Destroy(goClient);
            butStartClient.interactable = true;
        }

    }

    public void Exit_App() {
        //If we are running in the editor
        #if UNITY_EDITOR
            //Stop playing the scene
            UnityEditor.EditorApplication.isPlaying = false;
        #endif

        //If we are running in a standalone build of the game
        #if UNITY_STANDALONE
            //Quit the application
            Application.Quit();
        #endif

    }
}
